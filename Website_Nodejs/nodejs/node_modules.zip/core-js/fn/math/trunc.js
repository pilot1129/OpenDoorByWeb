require('../../modules/es6.math.trunc');
module.exports = require('../../modules/_core').Math.trunc;
