require('../../modules/core.function.part');
module.exports = require('../../modules/_core').Function.part;
