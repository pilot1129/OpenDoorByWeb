require('../modules/es7.asap');
module.exports = require('../modules/_core').asap;
